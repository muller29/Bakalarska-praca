const { EmailExists, CreateUser, FindUser } = require('User_DB');

const bcrypt = require('bcrypt');
const saltRounds = 10;

async function ValidateUserExists(email) {
    if(email === null || email === undefined) throw new Error("email is empty");

    let user = null;
    if (email){
        user = await EmailExists(email);
    }
    return user;
}

async function CreateNewUser(args){
    if (args.password){
        args.password = await _Encrypt(args.password);
    }
    return await CreateUser(args);
}

async function findUser(user_id){
    return FindUser(user_id);
}

module.exports = {
    ValidateUserExists,
    CreateNewUser,
    findUser
}

async function _Encrypt(text) {
    return await bcrypt.hash(text, saltRounds);
}