const db = require('../../models');
const Op = db.Sequelize.Op;

async function EmailExists(email) {
    if (email === null || email === undefined) throw new Error("No email was passed");

    const user = await db.user.findOne({
        where: {email}
    });

    if (user) return user;
    return null;
}

async function CreateUser(args){
    const user = await db.user.create({
       first_name: args.first_name,
       last_name: args.last_name,
       email: args.email,
       password: args.password,
       permission_id: args.permission_id
    });

    return user;
}

async function FindUser(credential){
    if (!credential) throw new Error('Invalid argument: user_id');
    const user = await db.user.findOne({
        where: {[Op.or] : [{id: credential}, {email: credential}]}
    });

    if (user) return user;
    return null;
}

module.exports = {
    EmailExists,
    CreateUser,
    FindUser
}