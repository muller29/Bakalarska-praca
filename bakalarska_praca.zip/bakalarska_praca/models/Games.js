"use strict";

module.exports = (sequelize, Datatypes) => {
    return sequelize.define(
        "game",
        {
            id: {
                type: Datatypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            word:{
                type: Datatypes.STRING,
                required: true,
                allowNull: false
            },
            rows:{
                type: Datatypes.INTEGER,
                required: true,
                allowNull: false
            },
            columns:{
                type: Datatypes.INTEGER,
                required: true,
                allowNull: false
            },
            barriers:{
                type: Datatypes.BOOLEAN,
                required: true,
                allowNull: false
            },
            additional_chars:{
                type: Datatypes.STRING,
                required: false,
                allowNull: true
            },
            max_time:{
                type: Datatypes.BIGINT,
                required: true,
                allowNull: false
            },
            level:{
                type: Datatypes.STRING,
                required: false,
                allowNull: true
            },
            task_id:{
                type: Datatypes.INTEGER,
                required: true,
                allowNull: false
            },
            updated_at: {
                type: Datatypes.DATE
            },
            created_at: {
                type: Datatypes.DATE
            },
        },
        { underscored: true, paranoid: true }
    );
};
