'use strict';

const fs = require('fs');
const path = require('path');
const Sequelize = require('sequelize');
const basename = path.basename(__filename);
const config = require('../config/config');
const db = {};

console.log(config);

const sequelize = new Sequelize(config.db.database, config.db.username, config.db.password, {
  dialect: "mysql",
  host: config.db.host,
    port: config.db.port
});

fs
  .readdirSync(__dirname)
  .filter(file => {
    return (file.indexOf('.') !== 0) && (file !== basename) && (file.slice(-3) === '.js');
  })
  .forEach(file => {
    const model = sequelize['import'](path.join(__dirname, file));
    db[model.name] = model;
  });

Object.keys(db).forEach(modelName => {
  if (db[modelName].associate) {
    db[modelName].associate(db);
  }
});

db.sequelize = sequelize;
db.Sequelize = Sequelize;

//Associations

// Permissions
db.permission.hasMany(db.user);

// Users
db.user.belongsTo(db.permission);
db.user.belongsTo(db.group);
db.user.belongsToMany(db.game, {
    through: "games_description",
    as: "games",
    foreignKey: "user_id"
});

// Groups
db.group.hasMany(db.user);
db.group.belongsToMany(db.task, {
    through: "tasks_group",
    as: "tasks",
    foreignKey: "group_id",
});

// Tasks
db.task.belongsToMany(db.group, {
   through: "tasks_group",
   as: "groups",
   foreignKey: "task_id"
});
db.task.hasMany(db.game);

// Games
db.game.belongsTo(db.task);
db.game.belongsToMany(db.user, {
    through: "games_description",
    as: "users",
    foreignKey: "game_id"
});



sequelize
    .authenticate()
    .then(() => {
      console.log('Connection has been established successfully.');
    })
    .catch(err => {
      console.error('Unable to connect to the database:', err);
    });

module.exports = db;
