"use strict";

module.exports = (sequelize, Datatypes) => {
    return sequelize.define(
        "task",
        {
            id: {
                type: Datatypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            name:{
                type: Datatypes.STRING,
                required: true,
                allowNull: false
            },
            from:{
                type: Datatypes.DATE,
                required: true,
                allowNull: false
            },
            to: {
                type: Datatypes.DATE,
                required: true,
                allowNull: false
            },
            image_path:{
                type: Datatypes.STRING,
                required: false,
                allowNull: true
            },
            updated_at: {
                type: Datatypes.DATE
            },
            created_at: {
                type: Datatypes.DATE
            },
        },
        { underscored: true, paranoid: true }
    );
};
