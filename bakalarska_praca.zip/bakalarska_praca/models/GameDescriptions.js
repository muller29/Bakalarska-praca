"use strict";

module.exports = (sequelize, Datatypes) => {
    return sequelize.define(
        "games_description",
        {
            id: {
                type: Datatypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            state:{
                type: Datatypes.STRING,
                required: true,
                allowNull: false
            },
            points:{
                type: Datatypes.INTEGER,
                required: true,
                allowNull: false
            },
            game_id:{
                type: Datatypes.INTEGER,
                required: true,
                allowNull: false
            },
            user_id:{
                type: Datatypes.INTEGER,
                required: true,
                allowNull: false
            },
            updated_at: {
                type: Datatypes.DATE
            },
            created_at: {
                type: Datatypes.DATE
            },
        },
        { underscored: true, paranoid: true }
    );
};
