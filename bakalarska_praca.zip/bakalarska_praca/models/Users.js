"use strict";

module.exports = (sequelize, Datatypes) => {
  return sequelize.define(
    "user",
    {
      id: {
          type: Datatypes.UUID,
          primaryKey: true,
          defaultValue: Datatypes.UUID
      },
      first_name: {
          type: Datatypes.STRING,
          isAlphanumeric: true,
          required: true,
          allowNull: true
      },
      last_name: {
          type: Datatypes.STRING,
          isAlphanumeric: true,
          required: true,
          allowNull: true,
          len:[8,20]
      },
      username: {
          type: Datatypes.STRING,
          isAlphanumeric: true,
          required: true,
          allowNull: true,
          len:[8,20]
      },
      password: {
          type: Datatypes.STRING,
          isAlphanumeric: true,
          required: true,
          allowNull: true,
          len:[8,20]
      },
      email: {
          type: Datatypes.STRING,
          isAlphanumeric: true,
          required: true,
          allowNull: true,
          len:[6,20],
          isEmail: true
      },
        permission_id:{
            type: Datatypes.INTEGER,
            required: true,
            allowNull: false
        },
        group_id:{
            type: Datatypes.INTEGER,
            required: false,
            allowNull: true
        },
      updated_at: {
          type: Datatypes.DATE
      },
      created_at: {
          type: Datatypes.DATE
      },
    },
    { underscored: true, paranoid: true }
  );
};
