"use strict";

module.exports = (sequelize, Datatypes) => {
    return sequelize.define(
        "group",
        {
            id: {
                type: Datatypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            name:{
                type: Datatypes.STRING,
                required: true,
                allowNull: false
            },
            updated_at: {
                type: Datatypes.DATE
            },
            created_at: {
                type: Datatypes.DATE
            },
        },
        { underscored: true, paranoid: true }
    );
};
