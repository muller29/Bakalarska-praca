"use strict";

module.exports = (sequelize, Datatypes) => {
    return sequelize.define(
        "tasks_group",
        {
            id: {
                type: Datatypes.INTEGER,
                autoIncrement: true,
                primaryKey: true
            },
            group_id:{
                type: Datatypes.INTEGER,
                required: true,
                allowNull: false
            },
            task_id:{
                type: Datatypes.INTEGER,
                required: true,
                allowNull: false
            },
            updated_at: {
                type: Datatypes.DATE
            },
            created_at: {
                type: Datatypes.DATE
            },
        },
        { underscored: true, paranoid: true }
    );
};
