const express = require('express');
const router = express.Router();
const asyncHandler = require('../Helpers/asyncHandler');
const validate = require('validate.js');
const User = require("../Services/Users/User_Service");

router.POST('/', asyncHandler(async(req, res) => {
    const constraints = {
        first_name: {
            presence: true,
            length: {maximum: 120}
        },
        last_name: {
            presence: true,
            length: {maximum: 120}
        },
        email: {
            presence: true,
        },
        password: {
            presence: true,
            length: {minimum: 8}
        },
        permission_id:{
            presence: true
        }
    };
    const first_name = req.body.first_name;
    const last_name = req.body.last_name;
    const email = req.body.email;
    const password = req.body.password;
    const permission_id = req.body.permission_id;

    const validation = validate({first_name, last_name, email, password, permission_id}, constraints);

    if (validation) return res.status(400).json({error: validation});

    const found_user = await User.ValidateUserExists(email);
    if (found_user) return res.status(400).json({error: 'Emial is already taken'});

    return await User.CreateNewUser({first_name, last_name, email, password, permission_id});
}));

module.exports = router;