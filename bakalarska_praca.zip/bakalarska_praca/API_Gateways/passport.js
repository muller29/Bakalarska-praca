var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;

const User = require('../Services/Users/User_Service');

passport.use(new LocalStrategy(
    function(email, password, done) {
        User.findUser(email)
            .then(user => {
                bcrypt.compare(password, user.password)
                    .then(match => {
                        if (match) return done(done, null);
                        return done(null, false);
                    })
            })
            .catch(e => done(e));
    }
));