const User = require('../Services/Users/User_Service');

module.exports = (req, res, next) =>{
    const user_id = req.user ? req.user : null;
    if (user_id){
        User.findUser(user_id).then(user => {
            if (user){
                req.user_permission = user.permission_id;
            }
        });
    }else{
        next();
    }
}