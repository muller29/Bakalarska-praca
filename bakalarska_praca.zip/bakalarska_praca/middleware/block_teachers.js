module.exports = (req, res, next) =>{
    if (req.permission_id === 2) return res.status(403).json({error: 'Forbidden'});
    next();
}