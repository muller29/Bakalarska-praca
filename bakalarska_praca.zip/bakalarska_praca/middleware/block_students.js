module.exports = (req, res, next) =>{
    if (req.permission_id === 3) return res.status(403).json({error: 'Forbidden'});
    next();
}