V prototype mozeme vygenerovat prvu verziu hracej plochy vseliakych rozmerov, samozrejme pocet riadkov 
a stlpcov musi byt aspon 1. Pod mriezkou su kachlicky, ktore mozeme drag and drop-nut. Na policko, 
na ktore sme uz dali nejaku kachlicku, uz nem nedovoli dat druhu. Ak klikneme na generate 
(samozrejme mozme menit aj rozmery mriezky), znovu nam vygeneruje prazdnu mirezku.

Najdete aj kretke video o tom.